-------------------------
WooCommerce Authorize.net SIM Payment Module
Author: Buif.Dw
Support: support@browsepress.com
-----------------------------------

SIM is a hosted payment processing solution that handles all the steps in processing a transaction, including:

- Collecting customer payment information through a secure, hosted form 
- Generating a receipt to the customer
- Securely transmitting to the payment processing networks for settlement
- Funding of proceeds to the merchant’s bank account
- Securely storing cardholder information

 
Read more: http://www.authorize.net/support/SIM_guide.pdf

Thank you for purchase.
Sincerely,
support@browsepress.com
