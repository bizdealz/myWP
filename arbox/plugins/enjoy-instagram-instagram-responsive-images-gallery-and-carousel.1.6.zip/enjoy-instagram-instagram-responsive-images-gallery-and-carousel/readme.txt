=== Enjoy Instagram ===
Contributors: (mediabeta, frafra85, fabiodipa)
Donate link: http://www.mediabeta.com/enjoy-instagram/
Tags: Instagram plugin, Instagram, Instagram gallery, Instagram images, Lightbox Instagram,Grid Instagram view, Instagram responsive, Instagram touch, Instagram photos,Instagram posts, Instagram page, Instagram widgets
Requires at least: 3.0.1
Tested up to: 4.1.1
Version: 1.6
Stable tag: 1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display in your site awesome carousels or images sliders of Instagram photos by user or hashtag.

== Description ==

= Visualize Instagram Photos in your website! =

You can display awesome carousels or images sliders of Instagram photos by user or
hashtag. You can easily use Enjoy Instagram in your pages, posts, sidebars with
shortcodes or widgets.

Each photo can be shown in “Lightbox”or Grid mode. Everything is responsive and
optimized for mobile devices.

Here is Live Demo: http://www.mediabeta.com/enjoy-instagram/

= Features =

* Connected with your instagram account
* Display photos using instagram hashtags 
* Display photos by your Instagram account
* Shortcodes
* Use like a Widgets 
* Touch
* Completely responsive and Optimized Mobile Devices 
* Grid View Customizable
* Carousel View Customizable
* FadeIn Effect in Grid View
* Possibility of inserting the Shortcode in a text
* Very Simple Installation and Configuration

= PREMIUM VERSION =

See demo http://www.mediabetaprojects.com/enjoy-instagram-premium/

* NEW Polaroid View to overlay images as polaroid pictures
* NEW Album View to show your pictures organized for username and or hashtags
* NEW Badge View that will help you link to and promote your Instagram web profile
* Autoreload Stream of Photos
* Moderation Panel: In real time you can moderate new photos and decide to approve and to publish or to rejected (Watch how it works: https://www.youtube.com/watch?v=W6gNqlghbLE ).
* Autoplay
* Loop
* Possibility to choose what link on the photo: Lightbox, Instagram, Custom URL or nothing.
* Custom CSS: edit CSS, set border, margin, background and much more
* Custom Transition Effect
* Custom JS: set time to autoplay and speed, set name of prev and next buttons and much more.
* Possibility to choose if show photo’s author, caption and likes number.
* and many others features..

LIVE PREMIUM VERSION DEMO: http://www.mediabetaprojects.com/enjoy-instagram-premium/

== Installation ==

Installation and Configuration are very simple :

1. After you have installed and activated the plugin , go to Settings - > Enjoy Instagram and follow the instructions on the screen.
2. To add shortcode to editor click on the  Enjoy Instagram icon and choose where include a Carousel View or a Grid View.
3. Configure the display of your shortcodes from the plugin settings page
4. To add to the Sidebar Enjoy Instagram go to Appearance - > Widgets and configure to your liking widgets Enjoy Instagram


== Frequently Asked Questions ==

= My profile disappeared. What’s happened? =

Repeat Step 01 and Step 02 again. 


== Screenshots ==

1. Enjoy Instagram settings page
2. Enjoy Instagram settings page2
3. Your Instagram Profile
4. Control Panel for Grid View and Carousel View Settings
5. Front End View Example
6. Front End View Example
7. Front End View Example
8. Front End View Example

== Changelog ==

= 1.0 =
* Initial Version
= 1.01 =
* Bux Fix
= 1.1 =
* Bux Fix
= 1.2 =
* Bux Fix
= 1.3 =
* Bux Fix
= 1.4 =
* Fix warning for empty hashtag value
= 1.5 =
* Fix shortcode use and setting saving
= 1.5.1 =
* Bugs Fix
= 1.5.2 =
* Bug for utf8 4-byte (mobile emoticon) Fixed
= 1.5.3 =
* Support for swedish specific characters.
= 1.6 =
* Add support for https protocol

== Upgrade Notice ==

= 1.0 =
* Initial Version
= 1.01 =
* Bux Fix
= 1.1 =
* Bux Fix
= 1.2 =
* Bux Fix
= 1.3 =
* Bux Fix
= 1.4 =
* Fix warning for empty hashtag value
= 1.5 =
* Fix shortcode use and setting saving
= 1.5.1 =
* Bugs Fix
= 1.5.2 =
* Bug for utf8 4-byte (mobile emoticon) Fixed
= 1.5.3 =
* Support for swedish specific characters.
= 1.6 =
* Add support for https protocol