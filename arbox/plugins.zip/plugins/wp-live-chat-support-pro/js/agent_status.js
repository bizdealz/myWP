jQuery(document).load(function () {

    var wplc_agent_status = new Switchery("#wplc_agent_status");
    var changeCheckbox = document.querySelector('#wplc_agent_status');

    changeCheckbox.onchange = function () {
        console.log(this);
    };

});